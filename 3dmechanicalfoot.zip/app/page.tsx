"use client"

import { Suspense, useState, useEffect, useRef } from "react"
import dynamic from "next/dynamic"
import { ControlPanel } from "@/components/control-panel"
import { InfoCard } from "@/components/info-card"
import { Loader2, AlertTriangle, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export type LegParams = {
  footLength: number
  archHeight: number
  heelRadius: number
  toeCount: number
  tibiaLength: number
  femurLength: number
  legThickness: number
  kneeAngle: number
  ankleAngle: number
  hipAngle: number
  footRotation: number
  stepAngle: number
  verticalShift: number
  springStiffness: number
  dampingFactor: number
}

const CanvasScene = dynamic(() => import("@/components/canvas-scene"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full items-center justify-center bg-slate-900">
      <div className="text-center">
        <Loader2 className="h-8 w-8 animate-spin text-purple-400 mx-auto mb-2" />
        <p className="text-sm text-slate-300">Cargando visualización 3D...</p>
      </div>
    </div>
  ),
})

function ErrorFallback({ onReset }: { onReset: () => void }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-slate-900/95 backdrop-blur-sm z-50">
      <Card className="max-w-md p-6 bg-slate-800 border-red-500/50 shadow-2xl">
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0">
            <AlertTriangle className="w-8 h-8 text-red-500" />
          </div>
          <div className="flex-1 space-y-3">
            <h2 className="text-xl font-bold text-red-400">Error en la Visualización 3D</h2>
            <p className="text-sm text-slate-300">
              Ha ocurrido un error al renderizar el modelo. Por favor recarga la aplicación.
            </p>
            <Button onClick={onReset} className="w-full bg-red-600 hover:bg-red-700">
              <RotateCcw className="mr-2 h-4 w-4" />
              Recargar
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}

export default function Home() {
  const [params, setParams] = useState<LegParams>({
    footLength: 26,
    archHeight: 4,
    heelRadius: 5,
    toeCount: 5,
    tibiaLength: 38,
    femurLength: 45,
    legThickness: 6,
    kneeAngle: 0,
    ankleAngle: 0,
    hipAngle: 0,
    footRotation: 0,
    stepAngle: 0,
    verticalShift: 0,
    springStiffness: 0.5,
    dampingFactor: 0.3,
  })

  const [isAnimating, setIsAnimating] = useState(false)
  const [useGLTF, setUseGLTF] = useState(false)
  const [gltfUrl, setGltfUrl] = useState("")
  const [gltfError, setGltfError] = useState<string | null>(null)
  const [hasError, setHasError] = useState(false)
  const errorCountRef = useRef(0)

  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      errorCountRef.current++
      if (errorCountRef.current > 2) {
        setHasError(true)
      }
    }

    window.addEventListener("error", handleError)
    return () => window.removeEventListener("error", handleError)
  }, [])

  const handleParamChange = (key: keyof LegParams, value: number) => {
    setParams((prev) => ({ ...prev, [key]: value }))
  }

  const resetValues = () => {
    setParams({
      footLength: 26,
      archHeight: 4,
      heelRadius: 5,
      toeCount: 5,
      tibiaLength: 38,
      femurLength: 45,
      legThickness: 6,
      kneeAngle: 0,
      ankleAngle: 0,
      hipAngle: 0,
      footRotation: 0,
      stepAngle: 0,
      verticalShift: 0,
      springStiffness: 0.5,
      dampingFactor: 0.3,
    })
    setIsAnimating(false)
    setGltfError(null)
  }

  const animateWalk = () => {
    if (isAnimating) return
    setIsAnimating(true)

    const duration = 3000
    const startTime = Date.now()

    const step = () => {
      const elapsed = Date.now() - startTime
      const progress = elapsed / duration

      if (progress < 1) {
        const phase = progress * Math.PI * 2

        setParams((prev) => ({
          ...prev,
          kneeAngle: Math.abs(Math.sin(phase)) * 70,
          ankleAngle: Math.sin(phase) * 30,
          hipAngle: Math.sin(phase + Math.PI / 4) * 20,
          stepAngle: Math.sin(phase) * 40,
          verticalShift: Math.abs(Math.sin(phase)) * 12,
        }))

        requestAnimationFrame(step)
      } else {
        setParams((prev) => ({
          ...prev,
          kneeAngle: 0,
          ankleAngle: 0,
          hipAngle: 0,
          stepAngle: 0,
          verticalShift: 0,
        }))
        setIsAnimating(false)
      }
    }

    step()
  }

  if (hasError) {
    return (
      <div className="flex h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 items-center justify-center">
        <ErrorFallback onReset={() => window.location.reload()} />
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Canvas 3D */}
      <div className="flex-1 relative">
        <Suspense
          fallback={
            <div className="flex h-full items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
            </div>
          }
        >
          <CanvasScene
            params={params}
            useGLTF={useGLTF}
            gltfUrl={gltfUrl}
            gltfError={gltfError}
            setGltfError={setGltfError}
          />
        </Suspense>

        {/* Info Card Overlay */}
        <InfoCard params={params} />

        {/* Error Display */}
        {gltfError && (
          <div className="absolute top-20 left-1/2 -translate-x-1/2 bg-red-500/90 text-white px-6 py-3 rounded-lg shadow-xl max-w-md">
            <p className="text-sm font-semibold">Error al cargar modelo 3D:</p>
            <p className="text-xs mt-1">{gltfError}</p>
          </div>
        )}
      </div>

      {/* Control Panel */}
      <ControlPanel
        params={params}
        onParamChange={handleParamChange}
        onReset={resetValues}
        onAnimate={animateWalk}
        isAnimating={isAnimating}
        useGLTF={useGLTF}
        setUseGLTF={setUseGLTF}
        gltfUrl={gltfUrl}
        setGltfUrl={setGltfUrl}
        onClearError={() => setGltfError(null)}
      />
    </div>
  )
}
