"use client"

import { Suspense } from "react"
import { Canvas } from "@react-three/fiber"
import {
  OrbitControls,
  Environment,
  ContactShadows,
  PerspectiveCamera,
  GizmoHelper,
  GizmoViewcube,
} from "@react-three/drei"
import { MechanicalLeg } from "@/components/mechanical-leg"
import { GLTFModel } from "@/components/gltf-model"
import type { LegParams } from "@/app/page"

interface CanvasSceneProps {
  params: LegParams
  useGLTF: boolean
  gltfUrl: string
  gltfError: string | null
  setGltfError: (error: string | null) => void
}

export default function CanvasScene({ params, useGLTF, gltfUrl, gltfError, setGltfError }: CanvasSceneProps) {
  return (
    <Canvas
      shadows
      dpr={[1, 2]}
      gl={{ antialias: true, alpha: true }}
      onCreated={(state) => {
        state.gl.setClearColor(0x0f172a, 1)
      }}
    >
      <PerspectiveCamera makeDefault position={[80, 50, 80]} fov={45} />
      <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} minDistance={40} maxDistance={150} />

      <ambientLight intensity={0.4} />
      <directionalLight
        position={[30, 50, 30]}
        intensity={1.2}
        castShadow
        shadow-mapSize-width={4096}
        shadow-mapSize-height={4096}
        shadow-camera-far={200}
        shadow-camera-left={-50}
        shadow-camera-right={50}
        shadow-camera-top={50}
        shadow-camera-bottom={-50}
      />
      <directionalLight position={[-30, 30, -30]} intensity={0.6} />
      <pointLight position={[0, 30, 0]} intensity={0.5} color="#a78bfa" />

      <Environment preset="sunset" />

      <Suspense fallback={null}>
        {useGLTF && gltfUrl ? (
          <GLTFModel url={gltfUrl} params={params} onError={setGltfError} />
        ) : (
          <MechanicalLeg params={params} />
        )}
      </Suspense>

      <ContactShadows position={[0, -0.5, 0]} opacity={0.6} scale={150} blur={2.5} far={50} color="#000000" />

      <gridHelper args={[150, 30, "#8b5cf6", "#334155"]} />

      <GizmoHelper alignment="bottom-right" margin={[80, 80]}>
        <GizmoViewcube
          faces={["Derecha", "Izquierda", "Arriba", "Abajo", "Frente", "Atrás"]}
          color="white"
          strokeColor="black"
          textColor="black"
          hoverColor="#a78bfa"
        />
      </GizmoHelper>
    </Canvas>
  )
}
