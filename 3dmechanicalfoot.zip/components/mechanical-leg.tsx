"use client"

import { useRef, useMemo } from "react"
import { Shape, MeshStandardMaterial } from "three"
import { useFrame } from "@react-three/fiber"
import type { LegParams } from "@/app/page"
import type { Group } from "three"

export function MechanicalLeg({ params }: { params: LegParams }) {
  const legGroupRef = useRef<Group>(null)
  const hipJointRef = useRef<Group>(null)
  const kneeJointRef = useRef<Group>(null)
  const ankleJointRef = useRef<Group>(null)
  const footGroupRef = useRef<Group>(null)

  useFrame(() => {
    if (!hipJointRef.current || !kneeJointRef.current || !ankleJointRef.current || !footGroupRef.current) return

    const hipRad = (params.hipAngle * Math.PI) / 180
    const kneeRad = (params.kneeAngle * Math.PI) / 180
    const ankleRad = (params.ankleAngle * Math.PI) / 180
    const footRot = (params.footRotation * Math.PI) / 180
    const stepRad = (params.stepAngle * Math.PI) / 180

    hipJointRef.current.rotation.x = hipRad
    kneeJointRef.current.rotation.x = -kneeRad
    ankleJointRef.current.rotation.x = -ankleRad
    ankleJointRef.current.rotation.z = -stepRad
    footGroupRef.current.rotation.y = footRot

    if (legGroupRef.current) {
      legGroupRef.current.position.y = params.verticalShift
    }
  })

  const footShape = useMemo(() => {
    const { footLength: L, archHeight: archH, heelRadius: heelR } = params
    const shape = new Shape()

    const heelSegments = 50
    for (let i = 0; i <= heelSegments; i++) {
      const theta = Math.PI / 2 + (Math.PI * i) / heelSegments
      const x = heelR * Math.cos(theta) * 0.95
      const y = heelR * Math.sin(theta) * 1.1
      if (i === 0) shape.moveTo(x, y)
      else shape.lineTo(x, y)
    }

    const archSegments = 70
    const archLength = L - heelR - 12
    for (let i = 0; i <= archSegments; i++) {
      const t = i / archSegments
      const x = heelR + archLength * t
      const h = heelR + archLength / 2
      const a = archH / Math.pow(archLength / 2, 2)
      const widthFactor = 1 + 0.15 * Math.sin(Math.PI * t)
      const y = -a * Math.pow(x - h, 2) + archH * widthFactor
      shape.lineTo(x, y)
    }

    const toesStart = L - 12
    const toesSegments = 30
    for (let i = 0; i <= toesSegments; i++) {
      const t = i / toesSegments
      const x = toesStart + 12 * t
      const y = 3 * Math.sin(Math.PI * t * 0.8) * (1 - t * 0.5) + archH * 0.3
      shape.lineTo(x, y)
    }

    shape.lineTo(L, -2.5)
    shape.lineTo(heelR, -2.5)
    shape.lineTo(heelR * Math.cos(Math.PI / 2), heelR * Math.sin(Math.PI / 2))

    return shape
  }, [params])

  const extrudeSettings = useMemo(
    () => ({
      depth: 9,
      bevelEnabled: true,
      bevelThickness: 0.8,
      bevelSize: 0.6,
      bevelSegments: 5,
    }),
    [],
  )

  const hipSphereMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#e0b899", // Light skin tone
        metalness: 0.05,
        roughness: 0.9,
      }),
    [],
  )

  const hipRingMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#d4a87a",
        metalness: 0.1,
        roughness: 0.85,
      }),
    [],
  )

  const femurMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#e5c4a1", // Thigh muscle tone
        metalness: 0.05,
        roughness: 0.9,
      }),
    [],
  )

  const hydraulicMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#c4986e", // Muscle definition
        metalness: 0.15,
        roughness: 0.8,
      }),
    [],
  )

  const kneeSphereMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#d9b690",
        metalness: 0.05,
        roughness: 0.9,
      }),
    [],
  )

  const kneeHingeMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#b89872",
        metalness: 0.15,
        roughness: 0.8,
      }),
    [],
  )

  const springMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#c9a57c",
        metalness: 0.1,
        roughness: 0.85,
        emissive: "#8b6f47",
        emissiveIntensity: params.springStiffness * 0.05,
      }),
    [params.springStiffness],
  )

  const tibiaMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#ddb690", // Shin/calf tone
        metalness: 0.05,
        roughness: 0.9,
      }),
    [],
  )

  const reinforcementMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#ba9876",
        metalness: 0.1,
        roughness: 0.85,
      }),
    [],
  )

  const ankleSphereMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#d4b088",
        metalness: 0.05,
        roughness: 0.9,
      }),
    [],
  )

  const ankleRingMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#a88d6f",
        metalness: 0.15,
        roughness: 0.85,
      }),
    [],
  )

  const footMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#e8c8a0", // Foot skin tone
        metalness: 0.02,
        roughness: 0.95,
      }),
    [],
  )

  const toeBoltMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#d5b590",
        metalness: 0.05,
        roughness: 0.9,
      }),
    [],
  )

  const boltMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#b89978",
        metalness: 0.05,
        roughness: 0.9,
      }),
    [],
  )

  const supportMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#c9a882",
        metalness: 0.05,
        roughness: 0.9,
      }),
    [],
  )

  const shockMat = useMemo(
    () =>
      new MeshStandardMaterial({
        color: "#ad8d6f",
        metalness: 0.1,
        roughness: 0.85,
        emissive: "#8b6f47",
        emissiveIntensity: params.dampingFactor * 0.05,
      }),
    [params.dampingFactor],
  )

  return (
    <group ref={legGroupRef}>
      <group ref={hipJointRef} position={[0, params.femurLength + params.tibiaLength, 0]}>
        {/* Hip Joint */}
        <mesh castShadow receiveShadow>
          <sphereGeometry args={[params.legThickness * 0.9, 32, 32]} />
          <primitive object={hipSphereMat} />
        </mesh>

        <mesh rotation={[Math.PI / 2, 0, 0]} castShadow receiveShadow>
          <torusGeometry args={[params.legThickness * 0.95, params.legThickness * 0.15, 16, 32]} />
          <primitive object={hipRingMat} />
        </mesh>

        {/* Femur (thigh) */}
        <mesh position={[0, -params.femurLength / 2, 0]} castShadow receiveShadow>
          <cylinderGeometry args={[params.legThickness * 0.85, params.legThickness * 0.7, params.femurLength, 32]} />
          <primitive object={femurMat} />
        </mesh>

        {/* Muscle definition */}
        <mesh position={[params.legThickness * 0.5, -params.femurLength / 2, 0]} castShadow receiveShadow>
          <cylinderGeometry args={[0.7, 0.7, params.femurLength * 0.8, 16]} />
          <primitive object={hydraulicMat} />
        </mesh>

        <group ref={kneeJointRef} position={[0, -params.femurLength, 0]}>
          {/* Knee */}
          <mesh castShadow receiveShadow>
            <sphereGeometry args={[params.legThickness * 0.9, 32, 32]} />
            <primitive object={kneeSphereMat} />
          </mesh>

          <mesh rotation={[0, 0, Math.PI / 2]} castShadow receiveShadow>
            <cylinderGeometry
              args={[params.legThickness * 0.35, params.legThickness * 0.35, params.legThickness * 2.2, 20]}
            />
            <primitive object={kneeHingeMat} />
          </mesh>

          {/* Calf muscle */}
          <mesh position={[-params.legThickness * 0.6, -params.tibiaLength * 0.35, 0]} castShadow receiveShadow>
            <cylinderGeometry args={[0.65, 0.55, params.tibiaLength * 0.5, 16]} />
            <primitive object={springMat} />
          </mesh>

          {/* Tibia (shin) */}
          <mesh position={[0, -params.tibiaLength / 2, 0]} castShadow receiveShadow>
            <cylinderGeometry args={[params.legThickness * 0.7, params.legThickness * 0.55, params.tibiaLength, 32]} />
            <primitive object={tibiaMat} />
          </mesh>

          {/* Shin muscle bands */}
          {[0.25, 0.5, 0.75].map((pos, i) => (
            <mesh key={i} position={[0, -params.tibiaLength * pos, 0]} castShadow receiveShadow>
              <cylinderGeometry args={[params.legThickness * 0.78, params.legThickness * 0.78, 1.2, 8]} />
              <primitive object={reinforcementMat} />
            </mesh>
          ))}

          <group ref={ankleJointRef} position={[0, -params.tibiaLength, 0]}>
            {/* Ankle */}
            <mesh castShadow receiveShadow>
              <sphereGeometry args={[params.legThickness * 0.65, 32, 32]} />
              <primitive object={ankleSphereMat} />
            </mesh>

            <mesh rotation={[0, 0, Math.PI / 2]} castShadow receiveShadow>
              <torusGeometry args={[params.legThickness * 0.7, params.legThickness * 0.15, 16, 32]} />
              <primitive object={ankleRingMat} />
            </mesh>

            <group ref={footGroupRef} position={[0, -2, 0]}>
              {/* Foot */}
              <mesh rotation={[-Math.PI / 2, 0, 0]} position={[-params.footLength / 2, 0, -4]} castShadow receiveShadow>
                <extrudeGeometry args={[footShape, extrudeSettings]} />
                <primitive object={footMat} />
              </mesh>

              {/* Toes */}
              {Array.from({ length: params.toeCount }).map((_, i) => {
                const toeSpacing = 7 / (params.toeCount - 1)
                const zPos = -3.5 + i * toeSpacing
                const toeLength = i === 0 || i === params.toeCount - 1 ? 2.2 : 2.5
                return (
                  <group key={i} position={[params.footLength / 2 - 3, 1.5, zPos]}>
                    <mesh castShadow receiveShadow>
                      <cylinderGeometry args={[0.55, 0.45, toeLength, 12]} />
                      <primitive object={reinforcementMat} />
                    </mesh>
                    <mesh position={[1.6, 0, 0]} castShadow receiveShadow>
                      <sphereGeometry args={[0.45, 16, 16]} />
                      <primitive object={toeBoltMat} />
                    </mesh>
                  </group>
                )
              })}

              {/* Foot structure details */}
              {[
                [-params.footLength / 4, 2, 0],
                [params.footLength / 4, 2, 0],
                [0, 2, 3],
                [0, 2, -3],
              ].map((pos, i) => (
                <mesh
                  key={i}
                  position={pos as [number, number, number]}
                  rotation={[Math.PI / 2, 0, 0]}
                  castShadow
                  receiveShadow
                >
                  <cylinderGeometry args={[0.5, 0.5, 1.2, 10]} />
                  <primitive object={boltMat} />
                </mesh>
              ))}

              {/* Foot arch support */}
              <mesh position={[0, 1.5, 0]} castShadow receiveShadow>
                <boxGeometry args={[params.footLength * 0.9, 0.8, 7]} />
                <primitive object={supportMat} />
              </mesh>

              {/* Heel padding */}
              {[-2, 2].map((z, i) => (
                <mesh key={i} position={[-params.footLength / 3, 0.5, z]} castShadow receiveShadow>
                  <cylinderGeometry args={[0.75, 0.75, 2.2, 16]} />
                  <primitive object={shockMat} />
                </mesh>
              ))}
            </group>
          </group>
        </group>
      </group>
    </group>
  )
}
