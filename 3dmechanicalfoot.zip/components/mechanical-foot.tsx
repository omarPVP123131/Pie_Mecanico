"use client"

import { useRef, useEffect } from "react"
import { type Group, Shape } from "three"
import type { FootParams } from "@/app/page"

export function MechanicalFoot({ params }: { params: FootParams }) {
  const legGroupRef = useRef<Group>(null)
  const ankleJointRef = useRef<Group>(null)
  const footGroupRef = useRef<Group>(null)

  useEffect(() => {
    if (ankleJointRef.current && footGroupRef.current) {
      // Apply transformations
      const rotRad = (params.footRotation * Math.PI) / 180
      footGroupRef.current.rotation.y = rotRad

      const stepRad = (params.stepAngle * Math.PI) / 180
      ankleJointRef.current.rotation.z = -stepRad
    }

    if (legGroupRef.current) {
      legGroupRef.current.position.y = params.verticalShift
    }
  }, [params.footRotation, params.stepAngle, params.verticalShift])

  // Create foot shape using mathematical functions
  const createFootShape = () => {
    const { footLength: L, archHeight: archH, heelRadius: heelR } = params
    const shape = new Shape()

    // HEEL - Using polar coordinates (semicircle)
    const heelSegments = 30
    for (let i = 0; i <= heelSegments; i++) {
      const theta = Math.PI / 2 + (Math.PI * i) / heelSegments
      const x = heelR * Math.cos(theta)
      const y = heelR * Math.sin(theta)

      if (i === 0) {
        shape.moveTo(x, y)
      } else {
        shape.lineTo(x, y)
      }
    }

    // PLANTAR ARCH - Inverted parabola
    const archSegments = 40
    for (let i = 0; i <= archSegments; i++) {
      const t = i / archSegments
      const x = heelR + (L - heelR - 8) * t

      const h = heelR + (L - heelR - 8) / 2
      const a = archH / Math.pow((L - heelR - 8) / 2, 2)
      const y = -a * Math.pow(x - h, 2) + archH

      shape.lineTo(x, y)
    }

    // TOES - Smooth curve
    const toesStart = L - 8
    const toesSegments = 15
    for (let i = 0; i <= toesSegments; i++) {
      const t = i / toesSegments
      const x = toesStart + 8 * t
      const y = 2 * Math.sin(Math.PI * t)
      shape.lineTo(x, y)
    }

    // Close shape
    shape.lineTo(L, -2)
    shape.lineTo(heelR, -2)
    shape.lineTo(heelR * Math.cos(Math.PI / 2), heelR * Math.sin(Math.PI / 2))

    return shape
  }

  const footShape = createFootShape()
  const extrudeSettings = {
    depth: 8,
    bevelEnabled: true,
    bevelThickness: 0.5,
    bevelSize: 0.5,
    bevelSegments: 3,
  }

  return (
    <group ref={legGroupRef}>
      {/* Leg (Tibia) */}
      <mesh position={[0, params.tibiaLength / 2, 0]} castShadow>
        <cylinderGeometry args={[params.legThickness * 0.6, params.legThickness * 0.5, params.tibiaLength, 16]} />
        <meshStandardMaterial color="#8899cc" metalness={0.3} roughness={0.6} />
      </mesh>

      {/* Knee Joint */}
      <mesh position={[0, params.tibiaLength, 0]} castShadow>
        <sphereGeometry args={[params.legThickness * 0.7, 16, 16]} />
        <meshStandardMaterial color="#667788" metalness={0.5} roughness={0.4} />
      </mesh>

      {/* Ankle Joint */}
      <group ref={ankleJointRef} position={[0, 0, 0]}>
        <mesh castShadow>
          <sphereGeometry args={[params.legThickness * 0.5, 16, 16]} />
          <meshStandardMaterial color="#556677" metalness={0.6} roughness={0.3} />
        </mesh>

        {/* Foot Group */}
        <group ref={footGroupRef}>
          {/* Main Foot Mesh */}
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[-params.footLength / 2, 0, -4]} castShadow>
            <extrudeGeometry args={[footShape, extrudeSettings]} />
            <meshStandardMaterial color="#764ba2" metalness={0.2} roughness={0.7} />
          </mesh>

          {/* Mechanical Details - Bolts */}
          {[
            [-params.footLength / 4, 2, 0],
            [params.footLength / 4, 2, 0],
            [0, 2, 2],
            [0, 2, -2],
          ].map((pos, i) => (
            <mesh key={i} position={pos as [number, number, number]} rotation={[Math.PI / 2, 0, 0]} castShadow>
              <cylinderGeometry args={[0.4, 0.4, 1, 8]} />
              <meshStandardMaterial color="#333333" metalness={0.9} roughness={0.2} />
            </mesh>
          ))}

          {/* Additional mechanical details */}
          <mesh position={[0, 1, 0]} castShadow>
            <boxGeometry args={[params.footLength * 0.8, 0.5, 6]} />
            <meshStandardMaterial color="#555555" metalness={0.7} roughness={0.3} />
          </mesh>
        </group>
      </group>
    </group>
  )
}
