"use client"

import { useRef, useEffect, useState } from "react"
import type { Group } from "three"
import type { LegParams } from "@/app/page"
import * as THREE from "three"

interface GLTFModelProps {
  url: string
  params: LegParams
  onError?: (error: string | null) => void
}

export function GLTFModel({ url, params, onError }: GLTFModelProps) {
  const group = useRef<Group>(null)
  const [gltfData, setGltfData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  console.log("[v0] GLTFModel component mounted with URL:", url)

  useEffect(() => {
    if (!url) {
      console.log("[v0] No URL provided")
      return
    }

    setIsLoading(true)
    setGltfData(null)

    const loader = new THREE.GLTFLoader()

    // Handle texture paths for GLTF files with separate texture folders
    loader.setPath("")

    // Set up a manager to handle texture loading errors gracefully
    const manager = new THREE.LoadingManager()

    manager.onError = (url) => {
      console.warn("[v0] Failed to load resource:", url)
      // Don't fail completely on texture errors
    }

    loader.manager = manager

    console.log("[v0] Starting to load GLTF from:", url)

    loader.load(
      url,
      (gltf) => {
        console.log("[v0] GLTF loaded successfully:", gltf)
        setGltfData(gltf)
        setIsLoading(false)
        if (onError) onError(null)
      },
      (progress) => {
        const percent = progress.total > 0 ? (progress.loaded / progress.total) * 100 : 0
        console.log("[v0] Loading progress:", percent.toFixed(2) + "%")
      },
      (error) => {
        console.error("[v0] Error loading GLTF:", error)
        const errorMsg = "Error al cargar el modelo. Asegúrate de que el archivo y sus texturas sean accesibles."
        setIsLoading(false)
        if (onError) onError(errorMsg)
      },
    )

    // Cleanup
    return () => {
      if (gltfData?.scene) {
        gltfData.scene.traverse((child: any) => {
          if (child.geometry) child.geometry.dispose()
          if (child.material) {
            if (Array.isArray(child.material)) {
              child.material.forEach((mat: any) => mat.dispose())
            } else {
              child.material.dispose()
            }
          }
        })
      }
    }
  }, [url])

  useEffect(() => {
    if (!group.current || !gltfData?.scene) return

    console.log("[v0] Applying transforms to model")

    const rotY = (params.footRotation * Math.PI) / 180
    const rotX = (params.hipAngle * Math.PI) / 180

    group.current.rotation.y = rotY
    group.current.rotation.x = rotX
    group.current.position.y = params.verticalShift

    const scaleX = params.footLength / 26
    const scaleY = (params.tibiaLength + params.femurLength) / 83
    const scaleZ = params.legThickness / 6

    group.current.scale.set(scaleX, scaleY, scaleZ)

    // Enhance materials with better properties
    gltfData.scene.traverse((child: any) => {
      if (child instanceof THREE.Mesh) {
        child.castShadow = true
        child.receiveShadow = true

        if (child.material) {
          const mat = child.material as THREE.MeshStandardMaterial

          // If material has no texture or color is too bright/white, apply a default color
          if (!mat.map && (!mat.color || mat.color.getHex() === 0xffffff)) {
            mat.color.setHex(0xe5c4a1) // Skin tone default
          }

          // Adjust material properties for better realism
          mat.metalness = Math.min(mat.metalness || 0.1, 0.3)
          mat.roughness = Math.max(mat.roughness || 0.7, 0.5)
          mat.needsUpdate = true
        }
      }
    })
  }, [params, gltfData])

  if (isLoading) {
    console.log("[v0] GLTF is loading...")
    return null
  }

  if (!gltfData?.scene) {
    console.log("[v0] No GLTF scene available")
    return null
  }

  return (
    <group ref={group}>
      <primitive object={gltfData.scene} />
    </group>
  )
}
