"use client"

import type React from "react"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Play, RotateCcw, Download, Upload, AlertCircle } from "lucide-react"
import type { LegParams } from "@/app/page"

type ControlPanelProps = {
  params: LegParams
  onParamChange: (key: keyof LegParams, value: number) => void
  onReset: () => void
  onAnimate: () => void
  isAnimating: boolean
  useGLTF: boolean
  setUseGLTF: (value: boolean) => void
  gltfUrl: string
  setGltfUrl: (value: string) => void
  onClearError: () => void
}

export function ControlPanel({
  params,
  onParamChange,
  onReset,
  onAnimate,
  isAnimating,
  useGLTF,
  setUseGLTF,
  gltfUrl,
  setGltfUrl,
  onClearError,
}: ControlPanelProps) {
  const exportData = () => {
    const h = params.heelRadius + (params.footLength - params.heelRadius - 10) / 2
    const archLength = params.footLength - params.heelRadius - 10
    const a = params.archHeight / Math.pow(archLength / 2, 2)

    const data = `╔════════════════════════════════════════════════════════════════╗
║     INFORME MATEMÁTICO - PIERNA MECÁNICA COMPLETA 3D          ║
╚════════════════════════════════════════════════════════════════╝

📊 PARÁMETROS DEL DISEÑO
═══════════════════════════════════════════════════════════════

🦶 PIE:
  • Longitud: ${params.footLength} cm
  • Altura del arco: ${params.archHeight} cm
  • Radio del talón: ${params.heelRadius} cm
  • Número de dedos: ${params.toeCount}

🦵 PIERNA:
  • Longitud de tibia: ${params.tibiaLength} cm
  • Longitud de fémur: ${params.femurLength} cm
  • Grosor: ${params.legThickness} cm

🔧 ARTICULACIONES:
  • Ángulo de rodilla: ${params.kneeAngle}°
  • Ángulo de tobillo: ${params.ankleAngle}°
  • Ángulo de cadera: ${params.hipAngle}°

⚙️ PARÁMETROS MECÁNICOS:
  • Rigidez del resorte: ${params.springStiffness}
  • Factor de amortiguación: ${params.dampingFactor}


📐 FUNCIONES MATEMÁTICAS UTILIZADAS
═══════════════════════════════════════════════════════════════

1️⃣ TALÓN (Coordenadas Polares):
   
   Ecuación: r = r₀, θ ∈ [π/2, 3π/2]
   
   Donde: r₀ = ${params.heelRadius} cm
   
   Conversión a coordenadas cartesianas:
   x(θ) = r₀ · cos(θ) = ${params.heelRadius} · cos(θ)
   y(θ) = r₀ · sin(θ) = ${params.heelRadius} · sin(θ)
   
   Aplicación: Genera la geometría semicircular del talón


2️⃣ ARCO PLANTAR (Función Parabólica):
   
   Ecuación general: y = -a(x - h)² + k
   
   Parámetros calculados:
   h = ${h.toFixed(2)} cm  (posición del vértice en x)
   k = ${params.archHeight} cm  (altura máxima del arco)
   a = ${a.toFixed(6)}  (coeficiente de curvatura)
   
   Ecuación específica:
   y(x) = -${a.toFixed(6)}(x - ${h.toFixed(2)})² + ${params.archHeight}
   
   Dominio: x ∈ [${params.heelRadius}, ${params.footLength - 10}]
   
   Aplicación: Modela la curva natural del arco plantar


3️⃣ DEDOS (Función Sinusoidal con Amortiguación):
   
   Ecuación: y(t) = A · sin(πt) · (1 - 0.3t)
   
   Donde:
   A = 2.5 cm (amplitud)
   t ∈ [0, 1] (parámetro normalizado)
   
   Aplicación: Crea la curvatura suave de los dedos con decaimiento


4️⃣ ARTICULACIÓN DE RODILLA (Bisagra Esférica):
   
   Matriz de rotación en X:
   ⎡ 1      0           0      ⎤
   ⎢ 0   cos(θₖ)  -sin(θₖ) ⎥
   ⎣ 0   sin(θₖ)   cos(θₖ) ⎦
   
   Aplicación: Define la rotación de la rodilla en el eje X


5️⃣ SISTEMA DE AMORTIGUACIÓN (Ecuación Diferencial):
   
   Fuerza del resorte: Fₛ = -k · x
   Fuerza de amortiguación: Fₐ = -c · v
   
   Donde:
   k = ${params.springStiffness} (rigidez)
   c = ${params.dampingFactor} (amortiguación)
   
   Ecuación del movimiento:
   m·ẍ + c·ẋ + k·x = F(t)


🔄 TRANSFORMACIONES GEOMÉTRICAS
═══════════════════════════════════════════════════════════════

1️⃣ ROTACIÓN EN EL EJE Y (Pie):
   θ = ${params.footRotation}° = ${((params.footRotation * Math.PI) / 180).toFixed(4)} rad
   
   Matriz de transformación:
   ⎡ cos(θ)   0   sin(θ) ⎤
   ⎢   0      1     0    ⎥
   ⎣-sin(θ)   0   cos(θ) ⎦


2️⃣ ROTACIONES DE ARTICULACIONES:
   • Cadera (X):   φₕ = ${params.hipAngle}°
   • Rodilla (X):  φₖ = ${params.kneeAngle}°
   • Tobillo (X):  φₐ = ${params.ankleAngle}°
   • Pisada (Z):   φₚ = ${params.stepAngle}°


3️⃣ TRASLACIÓN VERTICAL:
   Vector de desplazamiento: Δy = ${params.verticalShift} cm
   
   Transformación:
   y' = y + Δy


📊 GEOMETRÍA 3D
═══════════════════════════════════════════════════════════════

Extrusión del pie:
  • Profundidad: 9 cm
  • Biselado: 0.8 cm (grosor), 0.6 cm (tamaño)
  • Segmentos de bisel: 5

Discretización de curvas:
  • Talón: 40 segmentos
  • Arco plantar: 60 segmentos  
  • Dedos: 20 segmentos

Primitivas cilíndricas (fémur):
  • Radio superior: ${(params.legThickness * 0.8).toFixed(2)} cm
  • Radio inferior: ${(params.legThickness * 0.65).toFixed(2)} cm
  • Altura: ${params.femurLength} cm
  • Segmentos radiales: 24

Primitivas cilíndricas (tibia):
  • Radio superior: ${(params.legThickness * 0.65).toFixed(2)} cm
  • Radio inferior: ${(params.legThickness * 0.5).toFixed(2)} cm
  • Altura: ${params.tibiaLength} cm


⚡ ANÁLISIS CINEMÁTICO
═══════════════════════════════════════════════════════════════

Longitud total de la pierna:
L_total = L_fémur + L_tibia = ${params.femurLength + params.tibiaLength} cm

Radio de trabajo (alcance máximo):
R_max = √(L_fémur² + L_tibia²) = ${Math.sqrt(params.femurLength ** 2 + params.tibiaLength ** 2).toFixed(2)} cm

Altura del centro de masa (aproximado):
h_cm ≈ (L_fémur + L_tibia) / 2 + Δy = ${((params.femurLength + params.tibiaLength) / 2 + params.verticalShift).toFixed(2)} cm


═══════════════════════════════════════════════════════════════
📅 Fecha de exportación: ${new Date().toLocaleString("es-ES")}
🔬 Generado por: Simulador 3D de Pierna Mecánica v2.0
═══════════════════════════════════════════════════════════════`

    const blob = new Blob([data], { type: "text/plain;charset=utf-8" })
    const url = URL.createObjectURL(blob)
    const downloadLink = document.createElement("a")
    downloadLink.href = url
    downloadLink.download = `pierna_mecanica_${new Date().getTime()}.txt`
    downloadLink.click()
    URL.revokeObjectURL(url)
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const validExtensions = [".glb", ".gltf"]
      const fileName = file.name.toLowerCase()
      const isValid = validExtensions.some((ext) => fileName.endsWith(ext))

      if (!isValid) {
        alert("Por favor selecciona un archivo GLB o GLTF válido")
        e.target.value = "" // Reset input
        return
      }

      console.log("[v0] Loading file:", file.name, "Size:", file.size, "bytes")

      const url = URL.createObjectURL(file)
      console.log("[v0] Created blob URL:", url)

      setGltfUrl(url)
      setUseGLTF(true)
      onClearError()
    }
  }

  return (
    <div className="w-[420px] bg-slate-900/95 backdrop-blur-md overflow-y-auto shadow-2xl border-l border-purple-500/30">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-2">
            Panel de Control Avanzado
          </h1>
          <p className="text-xs text-slate-400">Sistema de simulación biomecánica con ecuaciones paramétricas</p>
        </div>

        <Separator className="bg-purple-500/30" />

        {/* Model Type Selection */}
        <Card className="p-4 border-purple-500/30 bg-purple-950/30">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="use-gltf" className="text-sm font-semibold text-purple-300">
                Modelo GLB/GLTF Externo
              </Label>
              <Switch id="use-gltf" checked={useGLTF} onCheckedChange={setUseGLTF} />
            </div>

            {useGLTF && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-amber-400 text-xs bg-amber-950/30 p-2 rounded">
                  <AlertCircle className="h-4 w-4 flex-shrink-0" />
                  <span>Sube un archivo GLB/GLTF completo (con texturas embebidas)</span>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="file-upload" className="text-xs text-slate-400">
                    Subir archivo local
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="file-upload"
                      type="file"
                      accept=".glb,.gltf"
                      onChange={handleFileUpload}
                      className="text-xs bg-slate-950/50 border-purple-500/30 text-white file:text-purple-300 file:bg-purple-950/50 file:border-0 file:mr-2"
                    />
                    <Button size="icon" variant="outline" className="border-purple-500/30 bg-transparent" asChild>
                      <label htmlFor="file-upload" className="cursor-pointer">
                        <Upload className="h-4 w-4" />
                      </label>
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="gltf-url" className="text-xs text-slate-400">
                    O pega una URL
                  </Label>
                  <Input
                    id="gltf-url"
                    placeholder="https://ejemplo.com/modelo.glb"
                    value={gltfUrl}
                    onChange={(e) => setGltfUrl(e.target.value)}
                    className="text-xs bg-slate-950/50 border-purple-500/30 text-white placeholder:text-slate-500"
                  />
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Foot Dimensions */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold text-purple-400 border-b-2 border-purple-500 pb-1 flex-1">
              Dimensiones del Pie
            </h2>
            <Badge variant="outline" className="border-purple-500/50 text-purple-300 text-xs">
              4 parámetros
            </Badge>
          </div>

          <ControlSlider
            label="Longitud del Pie"
            value={params.footLength}
            onChange={(v) => onParamChange("footLength", v)}
            min={20}
            max={35}
            step={0.5}
            unit="cm"
            formula="Base estructural"
          />

          <ControlSlider
            label="Altura del Arco"
            value={params.archHeight}
            onChange={(v) => onParamChange("archHeight", v)}
            min={2}
            max={8}
            step={0.2}
            unit="cm"
            formula="y = -a(x - h)² + k"
          />

          <ControlSlider
            label="Radio del Talón"
            value={params.heelRadius}
            onChange={(v) => onParamChange("heelRadius", v)}
            min={3}
            max={7}
            step={0.2}
            unit="cm"
            formula="r = r₀, θ ∈ [π/2, 3π/2]"
          />

          <ControlSlider
            label="Número de Dedos"
            value={params.toeCount}
            onChange={(v) => onParamChange("toeCount", v)}
            min={3}
            max={7}
            step={1}
            unit=""
            formula="Articulaciones mecánicas"
          />
        </div>

        <Separator className="bg-purple-500/30" />

        {/* Leg Dimensions */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold text-purple-400 border-b-2 border-purple-500 pb-1 flex-1">
              Dimensiones de la Pierna
            </h2>
            <Badge variant="outline" className="border-purple-500/50 text-purple-300 text-xs">
              3 parámetros
            </Badge>
          </div>

          <ControlSlider
            label="Longitud de Tibia"
            value={params.tibiaLength}
            onChange={(v) => onParamChange("tibiaLength", v)}
            min={30}
            max={50}
            step={1}
            unit="cm"
            formula="Segmento inferior"
          />

          <ControlSlider
            label="Longitud de Fémur"
            value={params.femurLength}
            onChange={(v) => onParamChange("femurLength", v)}
            min={35}
            max={55}
            step={1}
            unit="cm"
            formula="Segmento superior"
          />

          <ControlSlider
            label="Grosor General"
            value={params.legThickness}
            onChange={(v) => onParamChange("legThickness", v)}
            min={4}
            max={10}
            step={0.5}
            unit="cm"
            formula="Escala proporcional"
          />
        </div>

        <Separator className="bg-purple-500/30" />

        {/* Joint Angles */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold text-purple-400 border-b-2 border-purple-500 pb-1 flex-1">
              Ángulos de Articulaciones
            </h2>
            <Badge variant="outline" className="border-purple-500/50 text-purple-300 text-xs">
              3 articulaciones
            </Badge>
          </div>

          <ControlSlider
            label="Ángulo de Cadera"
            value={params.hipAngle}
            onChange={(v) => onParamChange("hipAngle", v)}
            min={-30}
            max={90}
            step={1}
            unit="°"
            formula="Rotación en X (flexión)"
          />

          <ControlSlider
            label="Ángulo de Rodilla"
            value={params.kneeAngle}
            onChange={(v) => onParamChange("kneeAngle", v)}
            min={0}
            max={140}
            step={1}
            unit="°"
            formula="Bisagra unidireccional"
          />

          <ControlSlider
            label="Ángulo de Tobillo"
            value={params.ankleAngle}
            onChange={(v) => onParamChange("ankleAngle", v)}
            min={-30}
            max={45}
            step={1}
            unit="°"
            formula="Dorsiflexión/plantarflexión"
          />
        </div>

        <Separator className="bg-purple-500/30" />

        {/* Transformations */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold text-purple-400 border-b-2 border-purple-500 pb-1 flex-1">
              Transformaciones
            </h2>
            <Badge variant="outline" className="border-purple-500/50 text-purple-300 text-xs">
              3 parámetros
            </Badge>
          </div>

          <ControlSlider
            label="Rotación del Pie"
            value={params.footRotation}
            onChange={(v) => onParamChange("footRotation", v)}
            min={-45}
            max={45}
            step={1}
            unit="°"
            formula="x' = x·cos(θ) - z·sin(θ)"
          />

          <ControlSlider
            label="Ángulo de Pisada"
            value={params.stepAngle}
            onChange={(v) => onParamChange("stepAngle", v)}
            min={-45}
            max={45}
            step={1}
            unit="°"
            formula="Rotación Z en tobillo"
          />

          <ControlSlider
            label="Elevación Vertical"
            value={params.verticalShift}
            onChange={(v) => onParamChange("verticalShift", v)}
            min={0}
            max={20}
            step={0.5}
            unit="cm"
            formula="Traslación en Y"
          />
        </div>

        <Separator className="bg-purple-500/30" />

        {/* Advanced Parameters */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold text-purple-400 border-b-2 border-purple-500 pb-1 flex-1">
              Parámetros Mecánicos
            </h2>
            <Badge variant="outline" className="border-amber-500/50 text-amber-300 text-xs">
              Avanzado
            </Badge>
          </div>

          <ControlSlider
            label="Rigidez del Resorte"
            value={params.springStiffness}
            onChange={(v) => onParamChange("springStiffness", v)}
            min={0}
            max={1}
            step={0.1}
            unit=""
            formula="k en Fₛ = -k·x"
          />

          <ControlSlider
            label="Factor de Amortiguación"
            value={params.dampingFactor}
            onChange={(v) => onParamChange("dampingFactor", v)}
            min={0}
            max={1}
            step={0.1}
            unit=""
            formula="c en Fₐ = -c·v"
          />
        </div>

        <Separator className="bg-purple-500/30" />

        {/* Actions */}
        <div className="space-y-3">
          <Button
            onClick={onAnimate}
            disabled={isAnimating}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold"
          >
            <Play className="mr-2 h-4 w-4" />
            {isAnimating ? "Animando..." : "Animar Ciclo de Marcha"}
          </Button>

          <div className="grid grid-cols-2 gap-2">
            <Button
              onClick={onReset}
              variant="outline"
              className="bg-slate-950/50 border-purple-500/30 text-purple-300 hover:bg-purple-950/50"
            >
              <RotateCcw className="mr-2 h-4 w-4" />
              Resetear
            </Button>

            <Button
              onClick={exportData}
              variant="outline"
              className="bg-slate-950/50 border-purple-500/30 text-purple-300 hover:bg-purple-950/50"
            >
              <Download className="mr-2 h-4 w-4" />
              Exportar
            </Button>
          </div>
        </div>

        {/* Mathematical Info */}
        <Card className="p-4 border-purple-500/30 bg-purple-950/20">
          <h3 className="text-sm font-semibold text-purple-300 mb-3 flex items-center gap-2">
            <span>📐</span> Ecuaciones Activas
          </h3>
          <div className="text-xs font-mono space-y-2 text-slate-300">
            <div className="bg-slate-950/50 p-2 rounded">
              <strong className="text-purple-400">Arco Plantar:</strong>
              <br />
              <span className="text-slate-400">y = -a(x - h)² + k</span>
            </div>
            <div className="bg-slate-950/50 p-2 rounded">
              <strong className="text-purple-400">Talón (Polar):</strong>
              <br />
              <span className="text-slate-400">r = r₀, θ ∈ [π/2, 3π/2]</span>
            </div>
            <div className="bg-slate-950/50 p-2 rounded">
              <strong className="text-purple-400">Rotación 3D:</strong>
              <br />
              <span className="text-slate-400">
                x' = x·cos(θ) - z·sin(θ)
                <br />
                z' = x·sin(θ) + z·cos(θ)
              </span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}

function ControlSlider({
  label,
  value,
  onChange,
  min,
  max,
  step,
  unit,
  formula,
}: {
  label: string
  value: number
  onChange: (value: number) => void
  min: number
  max: number
  step: number
  unit: string
  formula?: string
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-semibold text-slate-300">{label}</Label>
        <span className="text-sm font-bold text-purple-400">
          {value.toFixed(step < 1 ? 1 : 0)} {unit}
        </span>
      </div>
      <Slider
        value={[value]}
        onValueChange={(v) => onChange(v[0])}
        min={min}
        max={max}
        step={step}
        className="w-full"
      />
      {formula && (
        <p className="text-xs text-slate-500 font-mono bg-slate-950/30 p-2 rounded border-l-2 border-purple-500/50">
          {formula}
        </p>
      )}
    </div>
  )
}
